MATIBATIDOS POS RC6 - PROYECTO ANDROID

PASOS CORRECTOS PARA ESTE WORKFLOW:
1. Sube el ZIP completo, sin extraer, a la raíz del repositorio GitHub.
2. Conserva exactamente el nombre: Matibatidos_RC6_EXCEL_RENDIMIENTO_CORREGIDO_FIREBASE.zip
3. Abre Actions > Matibatidos POS + Delivery - acceso corregido > Run workflow.
4. Espera que todos los pasos terminen en verde.
5. Descarga el artefacto Matibatidos-POS-RC6-DELIVERY-MENU-FCM-1.2.4.

No subas los archivos extraídos para este workflow: espera el ZIP en la raíz.
No desinstales el POS de producción. La aplicación RC6 usa el identificador independiente com.matibatidos.pos.rc6.
Conserva un respaldo JSON antes de instalar o restaurar datos. La compilación debug no sustituye las pruebas en Android de login, restauración, Excel, WhatsApp, Bluetooth, impresión y respaldo.
